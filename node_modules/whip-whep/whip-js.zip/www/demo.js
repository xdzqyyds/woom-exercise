import { WHIPClient } from "../whip.js"
import { WHEPClient } from "../whep.js"

/*
 * 
SFO {id: 3809611, token: "d0edf67723a5941edda53a661a7bc17e322779f0523db504d946b91a1deb1661",�} 3A214B OiFL
AMS {id: 3809616, token: "cec471838ecbbe6f2450d49b0c0267fd6f7d55350ee966df4f547172c80cac7d",�} 3A2150 OiFQ
SGP {id: 3809600, token: "ab32423b1c3d68a4152378124bba464219d19b2fd51333e39e3c4fd9f052d725",�} 3A2140 OiFA


SFO {id: 771259733, token: "8d0217abec4d614b21d42178dbe8cbaf68ea242cb7ea9f63696aee504b41bea2",�} 2DF87D55 Lfh9VQ
AMS {id: 771257946, token: "f912653a7a643ebd65175ff4f5ba06cd7e66cdd7122be7ab944fd9d7ac030842",�} 2DF8765A Lfh2Wg
SGP {id: 771259156, token: "806bf77119989d41a56a2824fe93e47cff1a29b06744cf9871123d79897e3ed4",�} 2DF87B14 Lfh7FA



SFO baK8HF.OiFL.Lfh9VQ  7eb62f30b357827c3b904c15fddd147cabab6487e9835f8201b53c8f9d2d5d04 OiFL.Lfh9VQ.*
AMS baK8HF.OiFQ.Lfh2Wg  5f4c4e6a2bacd102b814de3b4b2a0e61f1394a52921f9d663c3bd9b9cdb702fa OiFQ.Lfh2Wg.*
SGP baK8HF.OiFA.Lfh7FA  07e196e3ae48d312c7153286126513d0ffe022cd63afadef9f9f59707ef533c6 OiFA.Lfh7FA.*
*/
const SFO = { appId: "baK8HF.OiFL.Lfh9VQ", appKey: "7eb62f30b357827c3b904c15fddd147cabab6487e9835f8201b53c8f9d2d5d04" }
const AMS = { appId: "baK8HF.OiFQ.Lfh2Wg", appKey: "5f4c4e6a2bacd102b814de3b4b2a0e61f1394a52921f9d663c3bd9b9cdb702fa" };
const SGP = { appId: "baK8HF.OiFA.Lfh7FA", appKey: "07e196e3ae48d312c7153286126513d0ffe022cd63afadef9f9f59707ef533c6" };


const { appId, appKey } = SFO;
const streamId = "mystream"
await true;

if (true)
{

	//Get mic+cam
	const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });

	//Create peerconnection
	const pc = window.pc = new RTCPeerConnection();

	//Send all tracks
	for (const track of stream.getTracks())
		//You could add simulcast too here
		pc.addTrack(track);

	//Create whip client
	const whip = window.whip = new WHIPClient();

	//const url = "https://192.168.64.2/whip/endpoint?codec=h264";
	//const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtaWxsaWNhc3QiOnsidHlwZSI6IlB1Ymxpc2giLCJzZXJ2ZXJJZCI6InB1YiIsInN0cmVhbUFjY291bnRJZCI6InRlc3QiLCJzdHJlYW1OYW1lIjoiZGZkIiwibXVsdGlzb3VyY2UiOmZhbHNlfSwiaWF0IjoxNjMxMjcxNTUxfQ.gvSqq0_1l-EO2tzuvw7L-17tkdCv3LXXlcuWeBFNQvM";

	//const url = "https://live-dev.millicast.com/api/pub/b041fe6772b047d480e03cad4b15daee/whip/endpoint";
	//const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtaWxsaWNhc3QiOnsidHlwZSI6IlB1Ymxpc2giLCJzdHJlYW1BY2NvdW50SWQiOiJtMk0yM3oiLCJzdHJlYW1OYW1lIjoiazlrbnUyZ2wiLCJzZXJ2ZXJJZCI6ImIwNDFmZTY3NzJiMDQ3ZDQ4MGUwM2NhZDRiMTVkYWVlIiwiY3VzdG9tRGF0YSI6eyJpc0RpcmVjdG9yIjpmYWxzZSwicmVxdWVzdElkIjoiYzgwMjVlNmIwYjE1NDAyMDk0MGRhMmMzMzM4NWMwNzIiLCJzdWJzY3JpYmVSZXF1aXJlc0F1dGgiOmZhbHNlfSwicmVjb3JkIjpmYWxzZX0sImlhdCI6MTYzMjQ3OTY0NywibmJmIjoxNjMyNDc5NjQ3LCJleHAiOjEwMDAwMDAwMDAwMTYzMjQ5MDAwMCwiYXVkIjoiTWlsbGljYXN0RGlyZWN0b3JSZXNvdXJjZSIsImlzcyI6Imh0dHBzOi8vZGlyZWN0b3IubWlsbGljYXN0LmNvbSJ9.cM4MZ5H4kFerVi23UgwM0ZZQzF5tACjU61fDt012ZW0";

	//const url = "https://director-dev.millicast.com/api/whip/kxep4h8f?sourceId=whip&codec=h264";
	//const token = "b7314479438e9a5c51c166e585ecbf91d83700d54eca7cb5a46a61d7bcdf12d2";


	//const url = "https://director-dev.millicast.com/api/whip/kwpdw24d";
	//const token = "e185442d1a673a58f00bce7ff3071ecea9d05f873cdcd254123adc092ab0a256";

	//const url = "https://mercury.conf.meetecho.com:8443/whip/endpoint/test";
	//const token = "hakcathon";


	//const url = "https://director.millicast.com/api/whip/stream1";
	//const token = "4cf9b50556bb64e135dd6951a746f91b23ad5d77521a3ebc35364fc61841d650";


	//const url = "https://director.millicast.com/api/whip/kx9hbhup";
	//const token = "1bf4929ffbff646c0ad88ad9073c026481c5d77318faa4bf618b4b8c597612eb";


	const url = `https://director.millicast.com/api/rtcbackup/push/${appId}/${streamId}?Vcodec=vp8`;
	//const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXJzaW9uIjoiMS4wIiwiYXBwSUQiOiJlN3VwdXAuQWk0ZC5mUSIsInN0cmVhbUlkIjoibXlzdHJlYW0iLCJhY3Rpb24iOiJwdXNoIiwiZW5hYmxlUHVsbEF1dGgiOnRydWUsImV4cCI6MTc1OTQyNjI0Mn0.TkI0pUN7XDMtWEBUWVj2-2CV6N5LYHNB8KJa69NRjNE";
	//const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXJzaW9uIjoiMS4wIiwiYXBwSUQiOiJiYUs4SEYuT2lGTC5MZmg5VlEiLCJzdHJlYW1JZCI6Im15c3RyZWFtIiwiYWN0aW9uIjoicHVzaCIsImVuYWJsZVB1bGxBdXRoIjp0cnVlLCJleHAiOjE3NTk0MjYyNDJ9.MpkePWVnqUNkBlZAzcBZihK_Fo6S0uf0S3_TYlCUwrE";
	//const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXJzaW9uIjoiMS4wIiwiYXBwSUQiOiJiYUs4SEYuT2lGTC5MZmg5VlEiLCJzdHJlYW1JZCI6Im15c3RyZWFtIiwiYWN0aW9uIjoicHVzaCIsImVuYWJsZVB1bGxBdXRoIjpmYWxzZSwiZXhwIjoxNzU5NDI2MjQyfQ.kO6Y37PuG6aD4XQxIeYEinHfMelGGQGY5iozTdrjcEU";
	//const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXJzaW9uIjoiMS4wIiwiYXBwSUQiOiJiYUs4SEYuT2lGUS5MZmgyV2ciLCJzdHJlYW1JZCI6Im15c3RyZWFtIiwiYWN0aW9uIjoicHVzaCIsImVuYWJsZVB1bGxBdXRoIjpmYWxzZSwiZXhwIjoxNzU5NDI2MjQyfQ.aqs4i2DqbiWZlMAS6sr3KKNFhsW7fIzA1qN7NTWtELs";
	const token = await gen(appId, appKey, streamId, "push", true)
	console.log(token);
	//Start publishing
	whip.publish(pc, url, token);

	const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

	if (connection)
		connection.addEventListener('change', (event) =>
		{
			console.dir(event)
			whip.restart();
		});
}

if (true)
{
	setTimeout(async () =>
	{
		//Create peerconnection
		const pc = window.pc = new RTCPeerConnection();

		//Add recv only transceivers
		pc.addTransceiver("audio");
		pc.addTransceiver("video");

		pc.ontrack = (event) =>
		{
			console.log(event)
			if (event.track.kind == "video")
				document.querySelector("video").srcObject = event.streams[0];

		}

		//Create whip client
		const whep = window.whep = new WHEPClient();
		const url = `https://director.millicast.com/api/rtcbackup/pull/${appId}/${streamId}`;
		const token = await gen(appId, appKey, streamId, "pull")
		//const token = null; //"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXJzaW9uIjoiMS4wIiwiYXBwSUQiOiJiYUs4SEYuT2lGTC5MZmg5VlEiLCJzdHJlYW1JZCI6Im15c3RyZWFtIiwiYWN0aW9uIjoicHVsbCIsImV4cCI6MTc1OTQyNjI0Mn0.TXpIU_ruMr0FMBOU-gQFTGuXo9W1wbLHuENccK2h8fY";
		//Start viewing
		whep.view(pc, url, token);
	}, 1000);
}


async function HMACSHA256(body, secret)
{
	const enc = new TextEncoder();
	const algorithm = { name: "HMAC", hash: "SHA-256" };

	const key = await crypto.subtle.importKey("raw", enc.encode(secret), algorithm, false, ["sign", "verify"]);
	const signature = await crypto.subtle.sign(algorithm.name, key, enc.encode(body));
	const digest = btoa(String.fromCharCode(...new Uint8Array(signature)));
	return digest;
}

async function gentoken(payload, appKey)
{
	console.dir(payload, appKey)

	const headers = {
		'type': 'JWT',
		'alg': 'HS256'
	}
	const encodedHeaders = trimEnd(encodeBase64UrlFix(btoa(JSON.stringify(headers))), '=');
	const encodedPayload = trimEnd(encodeBase64UrlFix(btoa(JSON.stringify(payload))), '=');
	const jwtRaw = `${encodedHeaders}.${encodedPayload}`;
	const signature = trimEnd(encodeBase64UrlFix(await HMACSHA256(jwtRaw, appKey)), '=');
	return `${jwtRaw}.${signature}`;
}

function genpayload(appId, streamId, action, enablePullAuth)
{
	return {
		"version": "1.0",
		appId,
		streamId,
		action,
		enablePullAuth,
		"exp": parseInt((Date.now() / 1000)) + 60
	};
}

async function gen(appId, appKey, streamId, action, enablePullAuth)
{
	console.log(appId, appKey)
	return await gentoken(genpayload(appId, streamId, action, enablePullAuth), appKey)
}

function trimEnd(str, removeChar)
{
	if (!str) return str;
	while (str.charAt(str.length - 1) === removeChar)
	{
		str = str.substring(0, str.length - 1);
	}
	return str;
}

function encodeBase64UrlFix(str)
{
	return str.replace(/\+/g, '-').replace(/\//g, '_');
}


function weirdBase64Encode(num)
{
	const bytes = uintToBytes(num);
	return arrayToBase64(new Uint8Array(bytes));
}

function uintToBytes(num)
{
	const buffer = new ArrayBuffer(4);
	const view = new DataView(buffer);
	view.setUint32(0, num, false);
	return buffer;
}

// plus weird 0 skipping
function arrayToBase64(bytes)
{
	let zeroIndex = 0;
	while (zeroIndex < bytes.byteLength && bytes[zeroIndex] === 0)
	{
		zeroIndex++;
	}
	let binary = '';
	for (let i = zeroIndex; i < bytes.byteLength; i++)
	{
		binary += String.fromCharCode(bytes[i]);
	}
	const base64Str = btoa(binary);
	return trimEnd(base64Str, '=');
}
async function generateAppKey(publishTokenStr, subscribeTokenStr) {
  const msgBuffer = new TextEncoder().encode(`${publishTokenStr}${subscribeTokenStr}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}
window.generateAppKey = generateAppKey;
window.weirdBase64Encode = weirdBase64Encode;